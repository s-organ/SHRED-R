PRDS.cutoff<-function(weights,parents,level){
    return(sum(weights)/level)
}

SHRED.cutoff<-function(weights,parents,level){
    sigmaI<-sum(weights[-parents[!is.na(parents)]]) # sigma({1, ... , m})
    return((sum(weights)*(1+log(sigmaI))-sum(weights*log(weights)))/level)
}

SHREDDER.cutoff<-function(weights,parents,level){
    m<-sum(weights)-sum(weights[unique(parents[!is.na(parents)])]) # sum of all minimal weights
    return(m/level)
}

CumMinWeights<-function(weights,parents){
### Calculates the cumulative minimal element weights for a
### hierarchical tree.  That is, the sum of the minimal elements in
### the first k elements of the weight vector.

### Future versions could extend this to arbitrary posets, but this
### has challenges --- we would need to encode the poset in an
### efficient way.
    
### weights --- the vector of node weights
### parents --- a vector of indices of the parent of each node, (NA for
###             the root node)
    
    up.par<-parents


### Remove nodes that appear after a descendent node, since they are
### never minimal elements.
    adj.weight<-weights
    for(i in seq_along(up.par)){
        while(!is.na(up.par[i])&&up.par[i]>i){
            adj.weight[up.par[i]]<-0
            up.par[i]<-up.par[up.par[i]]
        }
    }
### Now form a vector aw of the weights which are not minimal. 
### These are subtracted from all weights. 
    used<-rep(FALSE,length(weights))
    aw<-rep(0,length(adj.weight))
    for(i in seq_along(weights)){
        if(!is.na(up.par[i])&&!used[up.par[i]]){
            aw[i]<-adj.weight[up.par[i]]
            used[up.par[i]]<-TRUE
        }        
    }
    aw[is.na(aw)]<-0
    cum.weight.red<-cumsum(aw)
    return(cumsum(adj.weight)-cum.weight.red)
}


HGLSUP<-function(pvals,weights,parents,threshold){
### Hierarchical GLSUP

### pvals is the vector of p-values
### weights is the vector of weights
### parents is the vector indicating the parent of each hypothesis in
### the hierarchical tree.
### threshold is the cut-off slope.

### This function rejects as many hypotheses as possible such that the
### total weight of all rejected hypotheses exceeds threshold times
### p-value.

    ord<-order(pvals)
    ord.inv<-rep(0,length(pvals))
    ord.inv[ord]<-seq_along(ord) #inverse permutation

    ord.pv<-pvals[ord]
    ord.weight<-weights[ord]
    ord.par<-ord.inv[parents[ord]]

    cum.weight<-CumMinWeights(ord.weight,ord.par)

    suppressWarnings({select<-max(which(cum.weight/ord.pv>threshold))})
    selected<-ord.inv<=select

### Only report minimal selected sets. Non-minimal sets are implicitly
### selected.
    
    for(i in seq_along(selected)){
        if(selected[i]){
            j<-parents[i]
            while(!is.na(j)){
                selected[j]<-FALSE
                j<-parents[j]
            }
        }
    }
    return(list("pv"=ord.pv,
                "ord"=ord,
                "parent"=ord.par,
                "weight"=ord.weight,
                "cum.weight"=cum.weight,
                "selected"=selected,
                "pv.cut.off"=ord.pv[select]))
}


SHRED<-function(x,y,test,method,level,weights=NULL){
### Performs complete SHRED method
### x      --- the matrix of predictors
### y      --- the response variable
### level  --- the desired FDR control level
### test   --- one of "gaussian", "binomial" or "poisson"
###            or a list with two components -
    ##            "model" - a function for fitting a model
    ##            "p.val" - a function for extracting a p-value
    ##                      comparing a model and a submodel
### method --- the method used for selecting the threshold:
    ##            "PRDS" uses a cut.off that controls FDR under the
    ##                PRDS assumption on true null p-values
    ##            "Arbitrary" uses a cut.off that controls FDR under
    ##                arbitrary dependence assumptions (similar to BY)
    ##            "Heuristic" uses a BH cut.off that is not guaranteed to
    ##                control FDR but often performs well in practice
    ##            if numeric, then it will be used directly as a threshold
### weights --- a weighting scheme. Currently, this should be a
###             function of the size of the cluster. Could implement more
###             advanced versions that use structure or correlation.
    
    clust<-ClustOfVar::hclustvar(x)    
    clmat<-convert.to.matrix(clust)
    
    pvals<-get.p.vals(x,y,clmat$matrix,test)
    
    if(is.null(weights)){
        weights<-1/rowSums(clmat$matrix) # default weighting scheme
    }else if(is.function(weights)){
        weights<-weights(rowSums(clmat$matrix))
    }
    
    if(method=="PRDS"){
        threshold<-PRDS.cutoff(weights,clmat$parent,level)
    }else if(method=="Arbitrary"){
        threshold<-SHRED.cutoff(weights,clmat$parent,level)
    }else if(method=="Heuristic"){
        threshold<-SHREDDER.cutoff(weights,clmat$parent,level)
    }else if(is.numeric(method)){
        ## Can manually override method.
        threshold<-method
    }else{
        stop(paste( "Method \"",method,"\" not available for this package.",sep=""))
    }
    BH.results<-HGLSUP(pvals,weights,clmat$parent,threshold)
    
    ans<-list(
        "X"=x,
        "Y"=y,
        "method"=method,
        "test"=test,
        "level"=level,
        "cut.off.slope"=threshold,
        "threshold"=BH.results$pv.cut.off,
        "cluster"=clust,
        "cluster.matrix"=clmat,
        "pv"=BH.results$pv,
        "ord"=BH.results$ord,
        "weight"=weights,
        "cum.weight"=BH.results$cum.weight,
        "selected"=BH.results$selected,
        "selected.sets"=apply(clmat$matrix,2,as.logical)[BH.results$selected,,drop=FALSE],
        "selected.weight"=sum(weights[BH.results$selected])
    )
    
    class(ans)<-"SHRED"
    return(ans)    

}

SHREDDER<-function(x,y,test,level,weights=NULL){
### Performs complete SHREDDER method
### x     --- the matrix of predictors
### y     --- the response variable
### level --- the desired FDR control level
### test  --- one of "gaussian", "binomial" or "poisson"
###           or a list with two components -
    ##            "model" - a function for fitting a model
    ##            "p.val" - a function for extracting a p-value
    ##                      comparing a model and a submodel
### weights --- a weighting scheme. Currently, this should be a
###             function of the size of the cluster. Could implement more
###             advanced versions that use structure or correlation.
    
    clust<-ClustOfVar::hclustvar(x)    
    clmat<-convert.to.matrix(clust)

    pvals<-get.p.vals(x,y,clmat$matrix,test)

    if(is.null(weights)){
        weights<-1/rowSums(clmat$matrix) # default weighting scheme
    }else if(is.function(weights)){
        weights<-weights(rowSums(clmat$matrix))
    }

    
    ## First replace p-values with highest p-values above

### We are using the fact that hclustvar clusters parent clusters before
### children clusters, so by the time a child cluster is reached, the parent
### cluster will already have the highest p-value above it in the tree.
### If the ClustOfVar package ever changes this functionality, this code
### will break.
    for(i in seq_along(pvals)){
        if(!is.na(clmat$parent[i])&&pvals[clmat$parent[i]]>pvals[i]){
            pvals[i]=pvals[clmat$parent[i]]
        }
    }

    threshold<-SHREDDER.cutoff(weights,clmat$parent,level)
    
    BH.results<-HGLSUP(pvals,weights,clmat$parent,threshold)

    ans<-list(
        "X"=x,
        "Y"=y, 
        "method"="SHREDDER",
        "test"=test,
        "level"=level,
        "cut.off.slope"=threshold,
        "threshold"=BH.results$pv.cut.off,
        "cluster"=clust,
        "cluster.matrix"=clmat,
        "pv"=BH.results$pv,
        "ord"=BH.results$ord,
        "weight"=weights,
        "cum.weight"=BH.results$cum.weight,
        "selected"=BH.results$selected,
        "selected.sets"=apply(clmat$matrix,2,as.logical)[BH.results$selected,,drop=FALSE],
        "selected.weight"=sum(weights[BH.results$selected])
    )
    
    class(ans)<-c("SHREDDER","SHRED")
    return(ans)    
}

###Print method for displaying output of SHRED and SHREDDER

print.SHRED<-function(x,...){
    p<-dim(x$X)[2]
    vnames<-paste("X",seq_len(p),sep="") # Default column names.
    if(!is.null(names(x$X))){
        vnames<-names(x$X)
    }
    if("SHREDDER" %in% class(x)){
        cat("Variable sets selected using SHREDDER variable selection method.\n")
    }else{
        cat("Variable sets selected using SHRED variable selection method.\n")
        if(is.numeric(x$method)){
            cat(paste("Threshold slope set manually as ",x$method,".\n",sep=""))
        }else{
            cat(paste("Threshold slope calculated using \"",x$method,"\" method.\n",sep=""))
        }            
    }

    cat(paste("\n\nThreshold slope:",x$cut.off.slope))
    cat(paste("\nThreshold:",x$threshold))
    nsel<-sum(x$selected)
    cat(paste("\n\nSelected a total of ",nsel," sets with total weight ",x$selected.weight,".\n\n",sep=""))
### This won't work perfectly with long variable names.
    for(i in seq_len(nsel)){
        cat(i)
        cat("\t")
        vs<-vnames[x$selected.sets[i,]]
        for(j in seq_along(vs)){
            cat(vs[j])
            cat("\t")
        }
        cat("\n")
    }
}

### S3 method to plot SHRED results.

plot.SHRED<-function(x,...){
    graphics::plot.default(x$pv,x$cum.weight,xlim=c(0,1),xlab="p-value",ylab="Cumulative Weight of Rejected Hypotheses",...)
    graphics::abline(0,x$cut.off.slope,...)
}
