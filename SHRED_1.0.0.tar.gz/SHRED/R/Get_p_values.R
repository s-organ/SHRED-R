convert.to.matrix<-function(clust){
### this converts the clustering to a more convenient matrix format.
    if(!("hclust" %in% class(clust))){
        stop("Can only convert objects of class \"hclust\" to matrices.")
    }
    memb <- clust$clusmat
    p<- dim(memb)[1]
    
    ## memb is the matrix detailing the clusters obtained from the
    ## hierarchical clustering.  Each column corresponds to one level
    ## of the clustering, and in each column, the numbers are the
    ## first element of the corresponding cluster.
    
    ## turn memb into a matrix with 2p-1 rows of 1's and 0's for which
    ## variables are in which set

    mat <- matrix(1,2*p-1,p) # Assumes a full hierarchical clustering.
    parent <- rep(NA,2*p-1)
    for(i in seq_len(p-1)){
        col<-memb[,i]
        mat[2*i,]<-memb[,i]!=memb[,i+1]
        ## This extracts the class that was merged with an earlier class
        val<-(memb[as.logical(mat[2*i,]),i])[1]
        ## This is the number of the earlier class
        ## Also the first element of the class that was split.
        mat[2*i+1,]<-memb[,i+1]==val

        ## calculate which class is the parent class.
        parent[2*i+c(0,1)]<-max(which(mat[seq_len(2*i-1),val]==1))
    }
    return(list("parent"=parent,"matrix"=mat))
}

make.test<-function(test.name){
### Produces the standard hypothesis tests for testing sets of
### variables under common settings.
### Custom tests can be manually produced using the same format.
    
    if(test.name=="gaussian"){
        return(list("model"=stats::lm,
                    "p.val"=function(m1,m2){return(stats::anova(m1,m2)[2,"Pr(>F)"])}))
    }else if(test.name=="binomial"){
        return(list("model"=function(form){stats::glm(form, family = stats::binomial(link="logit"))},
                    "p.val"=function(m1,m2){return(stats::anova(m1,m2,test="Chisq")[2,"Pr(>Chi)"])}))
    }else if(test.name=="poisson"){
        return(list("model"=function(form){stats::glm(form, family = stats::poisson(link="log"))},
                    "p.val"=function(m1,m2){return(stats::anova(m1,m2,test="Chisq")[2,"Pr(>Chi)"])}))
    }else{
        stop(paste("Test \"",test.name,"\" not supported, please manually input test."))
    }
}


get.p.vals<-function(x,y,clust,test){
### x     --- the matrix of predictors
### y     --- the vector of response variables
### clust --- a logical matrix whose rows are subsets of columns of X.
### test  --- a list with two components:
###       model --- a function for fitting the model based on a formula
###                 typically "lm" for gaussian regression, something
###                 based on "glm" for other glm models.
###       p.val --- a test function based on comparison of the two models
###                 typically based on the anova function

### Could write something much faster for gaussian regression, where
### only a single fitting is needed.

    if(is.character(test)){
        ## certain strings are possible for test
        test<-make.test(test)
    }

    nc<-dim(clust)[1]
    pv<-rep(1,nc)
    full<-test$model(y~x)
    for(i in seq_len(nc)){
        x_sub<-x[,!(as.logical(clust[i,]))] # remove tested set of predictors
        if(dim(x_sub)[2]==0){
            ## empty submodel selected for comparison
            nested<-test$model(y~1)
        }else{
            nested<-test$model(y~x_sub)
        }
        pv[i]<-test$p.val(full,nested)
    }
    return(pv)
}
